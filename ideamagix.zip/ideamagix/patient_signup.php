<?php
session_start();
include 'get_db_connection.php';

if (isset($_POST['patientssignupsubmit'])) {
    $patientsname            = htmlspecialchars(($_POST['patientsname']));
    $patientsage             = trim($_POST['patientsage']);
    $patientsemail           = trim($_POST['patientsemail']);
    $patientsphonenumber     = trim($_POST['patientsphonenumber']);
    $patientssurgeryhistory  = htmlspecialchars(trim($_POST['patientssurgeryhistory']));
    $patientsillnesshistory  = htmlspecialchars(trim($_POST['patientsillnesshistory']));
    $patientspassword        = trim($_POST['patientspassword']);

    $createddate             = date('Y-m-d H:i:s');

    $patientsprofilepicture  =trim($_FILES['patientsprofilepicture']['name']);

    if($patientsprofilepicture){
       $patientsprofilepicture_extension = pathinfo($patientsprofilepicture,PATHINFO_EXTENSION);//get extention
       $patientsprofilepicture_rename    = $patientsname."patientsprofilepicture";//new name
       $patientsprofilepicture_newname   = $patientsprofilepicture_rename.'.'.$patientsprofilepicture_extension;//new name and extension
       $patientsprofilepicture_tmp       = $_FILES['patientsprofilepicture']['tmp_name'];
       $patientsprofilepicture_path      = 'patientsprofilepicture/'.$patientsprofilepicture_newname;
 }
    
    $query_check = "SELECT * FROM patientsmaster WHERE patientsemail = '$patientsemail' OR patientsphonenumber = '$patientsphonenumber'";
    $result_check = mysqli_query($conn, $query_check);
    
    if (mysqli_num_rows($result_check) > 0) {
        $_SESSION['status_failed'] = "Email or phone number already exists. Please choose another.";
        header('location: patient_signup.php');
        exit;
    } else {

        // Insert new user into the database
        
        $query_insert = "INSERT INTO patientsmaster (patientsprofilepicture, patientsname, patientsage, patientsemail, patientsphonenumber, patientssurgeryhistory, patientsillnesshistory, patientspassword, createddate, createdby, updateddate, updatedby) 
                                             VALUES ('$patientsprofilepicture_newname','$patientsname','$patientsage','$patientsemail','$patientsphonenumber','$patientssurgeryhistory','$patientsillnesshistory','$patientspassword','$createddate', 'admin', '$createddate', 'admin')";

        if (mysqli_query($conn, $query_insert)) {

            move_uploaded_file($patientsprofilepicture_tmp, $patientsprofilepicture_path);
            
            $_SESSION['status_success'] = "Sign-up successful. Please login.";
            header('location: patient_signin.php');
            exit;
        } else {
            $_SESSION['status_failed'] = "Sign-up failed. Please try again.";
            header('location: patient_signup.php'); 
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Sign-Up</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-center">Patient Sign-Up</h1>
                <?php
                if (isset($_SESSION['status_success'])) {
                    echo "<div class='alert alert-success'>".$_SESSION['status_success']."</div>";
                    unset($_SESSION['status_success']);
                }

                if (isset($_SESSION['status_failed'])) {
                    echo "<div class='alert alert-danger'>".$_SESSION['status_failed']."</div>";
                    unset($_SESSION['status_failed']);
                }
                ?>
                
                <form method="POST" action="" enctype='multipart/form-data'>
                    <div class="form-group">
                        <label  class="col-form-label">Profile Picture</label><br>
                        <input type="file" name="patientsprofilepicture" id="patientsprofilepicture" required>
                    </div>
                    <div class="form-group">
                        <label for="patientsnameid">Name</label>
                        <input type="text" class="form-control" id="patientsnameid" name="patientsname" placeholder="Enter your Name" required>
                    </div>
                    <div class="form-group">
                        <label for="patientsageid">AGE</label>
                        <input type="number" class="form-control" id="patientsageid" name="patientsage" placeholder="Enter your Age" required>
                    </div>
                    <div class="form-group">
                        <label for="patientsemailid">Email</label>
                        <input type="email" class="form-control" id="patientsemailid" name="patientsemail" placeholder="Enter your Email" required>
                    </div>
                    <div class="form-group">
                        <label for="patientsphonenumberid">Phone Number</label>
                        <input type="number" class="form-control" id="patientsphonenumberid" name="patientsphonenumber" placeholder="Enter your Phone Number" required>
                    </div>
                    <div class="form-group">
                        <label for="patientssurgeryhistoryid">Surgery History</label>
                        <textarea step="0.1" class="form-control" id="patientssurgeryhistoryid" name="patientssurgeryhistory" placeholder="Enter your Surgery History" required> </textarea>
                    </div>
                    <div class="form-group">
                        <label for="patientsillnesshistoryid">Illness History</label>
                        <textarea step="0.1"  class="form-control" id="patientsillnesshistoryid" name="patientsillnesshistory" placeholder="Enter your Illness History" required> </textarea>
                    </div>
                    <div class="form-group">
                        <label for="patientspasswordid">Password</label>
                        <input type="password" class="form-control" id="patientspasswordid" name="patientspassword" placeholder="Enter your Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block" name="patientssignupsubmit">Sign Up</button>
                
                </form>
            </div>
        </div>
    </div>
</body>
</html>
