<?php
session_start();
include 'get_db_connection.php'; 

if (isset($_POST['patientsigninsubmit'])) {
    // Sanitize user input
    $patientsemail = mysqli_real_escape_string($conn, $_POST['patientsemail']);
    $patientspassword = $_POST['patientspassword']; // Do not hash the password here, compare it later.

    // Query to find the patient by email
    $query = "SELECT * FROM patientsmaster WHERE patientsemail = '$patientsemail'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Fetch the patient's data
        $patient = mysqli_fetch_assoc($result);
        $stored_password = $patient['patientspassword']; // Password stored in the database

        // Check password (handles both plain text and hashed passwords)
        if ($stored_password === $patientspassword || password_verify($patientspassword, $stored_password)) {
            // Successful login
            echo "Login Successful";
            
            // Set session variables
            $_SESSION['patient_id'] = $patient['id'];
            $_SESSION['patient_name'] = $patient['name'];

            // Redirect to dashboard
            header("Location: doctorlist.php");
            exit;
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "patients not found!";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Sign-In</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3 class="text-center">Patient Sign-In</h3>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="patientsemailid">Email</label>
                        <input type="email" class="form-control" id="patientsemailid" name="patientsemail" placeholder="Enter your Email" required>
                    </div>
                    <div class="form-group">
                        <label for="patientspasswordid">Password</label>
                        <input type="password" class="form-control" id="patientspasswordid" name="patientspassword" placeholder="Enter your Password" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" name="patientsigninsubmit">Sign IN</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>


