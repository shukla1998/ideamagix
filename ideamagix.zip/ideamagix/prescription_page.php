<?php
session_start();
include 'get_db_connection.php';

if (isset($_POST['submit_prescription'])) {
    $patient_id = $_POST['patient_id'];
    $prescriptionscare = trim($_POST['prescriptionscare']);
    $prescriptionsmedicines = trim($_POST['prescriptionsmedicines']);
    $createddate = date('Y-m-d H:i:s');

    $query = "INSERT INTO prescriptionsmaster (patient_id, prescriptionscare, prescriptionsmedicines, createddate, createdby, updateddate, updatedby) VALUES ('$patient_id', '$prescriptionscare', '$prescriptionsmedicines', '$createddate', 'admin', '$createddate', 'admin')";
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['status_success'] = "Prescription submitted successfully.";
        header('Location: prescription_page.php?patient_id=' . $_POST['patient_id']);
        exit;
    } else {
        $_SESSION['status_failed'] = "Failed to submit prescription.";
    }
}

$patient_id = $_GET['patient_id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Write Prescription</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Write Prescription</h1>
        <?php
        if (isset($_SESSION['status_failed'])) {
            echo "<div class='alert alert-danger'>".$_SESSION['status_failed']."</div>";
            unset($_SESSION['status_failed']);
        }
        ?>
        <form method="POST" class="mt-4">
            <input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">
            <div class="form-group">
                <label for="prescriptionscare">Care to be Taken <span class="text-danger">*</span></label>
                <textarea class="form-control" id="prescriptionscareid" name="prescriptionscare" required></textarea>
            </div>
            <div class="form-group">
                <label for="prescriptionsmedicinesid">Medicines</label>
                <textarea class="form-control" id="prescriptionsmedicines" name="prescriptionsmedicines"></textarea>
            </div>
            <button type="submit" class="btn btn-primary" name="submit_prescription">Submit Prescription</button>
        </form>
    </div>
</body>
</html>
