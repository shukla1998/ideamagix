<?php 

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "ideamagixproject";

$conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

?>