<?php
session_start();
include 'get_db_connection.php';

$doctor_id = $_GET['doctor_id'];
if (isset($_POST['consultationsubmit'])) {
    $doctor_id = $_POST['doctor_id'];

    $consultationsillnesshistory = htmlspecialchars(trim($_POST['consultationsillnesshistory']));
    $consultationsrecentsurgery = htmlspecialchars(trim($_POST['consultationsrecentsurgery']));
    $consultationsdiabetes = htmlspecialchars(trim($_POST['consultationsdiabetes']));
    $consultationsallergies = htmlspecialchars(trim($_POST['consultationsallergies']));
    $consultationsothers = htmlspecialchars(trim($_POST['consultationsothers']));
    $consultationstransactionid = htmlspecialchars(trim($_POST['consultationstransactionid']));
    $consultationconsent = htmlspecialchars(trim($_POST['consultationconsent']));

    $createddate = date('Y-m-d H:i:s');

    // Insert consultation data
    $query_insert = "INSERT INTO consultationsmaster (doctor_id, consultationsillnesshistory, consultationsrecentsurgery, consultationsdiabetes, consultationsallergies,
                                                     consultationsothers, consultationstransactionid, consultationconsent, createddate, createdby, updateddate, updatedby) 
                     VALUES ('$doctor_id', '$consultationsillnesshistory', '$consultationsrecentsurgery', '$consultationsdiabetes', '$consultationsallergies', 
                             '$consultationsothers', '$consultationstransactionid', '$consultationconsent', '$createddate', 'admin', '$createddate', 'admin')";

    // Update patient record with doctor_id
    $patient_id = isset($_POST['patient_id']) ? intval($_POST['patient_id']) : 0;
    if ($patient_id > 0) {
        $update_patient_query = "UPDATE patientsmaster SET doctor_id = '$doctor_id' WHERE id = $patient_id";
        mysqli_query($conn, $update_patient_query);
    }

    if (mysqli_query($conn, $query_insert)) {
        $_SESSION['status_success'] = "Consultation submitted successfully!";
        header('location: consultation_form.php?doctor_id=' . $doctor_id);
        exit;
    } else {
        $_SESSION['status_failed'] = "Failed to submit consultation. Please try again.";
        header('location: consultation_form.php?doctor_id=' . $doctor_id);
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultation Form</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-step {
            display: none;
        }
        .form-step.active {
            display: block;
        }
    </style>
</head>
<body>
<?php
if (isset($_GET['doctor_id']) && !empty($_GET['doctor_id'])) {
    $doctor_fetch_query = "SELECT * FROM doctorsmaster WHERE id = '$doctor_id'";
    $doctor_fetch_query_run = mysqli_query($conn, $doctor_fetch_query);

    if (mysqli_num_rows($doctor_fetch_query_run) > 0) {
        $doctor_fetch_row = mysqli_fetch_assoc($doctor_fetch_query_run);
        $doctorsname = $doctor_fetch_row['doctorsname'];
    } else {
        echo "No doctor found with the provided ID.";
        exit;
    }
} else {
    echo "Doctor ID is missing in the URL.";
    exit;
}
?>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-center">Consultation Form</h1>
                <?php
                if (isset($_SESSION['status_success'])) {
                    echo "<div class='alert alert-success'>" . $_SESSION['status_success'] . "</div>";
                    unset($_SESSION['status_success']);
                }
                if (isset($_SESSION['status_failed'])) {
                    echo "<div class='alert alert-danger'>" . $_SESSION['status_failed'] . "</div>";
                    unset($_SESSION['status_failed']);
                }
                ?>
                <form method="POST" id="consultationForm">
                    <input type="hidden" name="doctor_id" value="<?php echo $doctor_id; ?>">
                    <input type="hidden" name="patient_id" value="<?php echo $_GET['patient_id'] ?? ''; ?>">

                    <!-- Step 1 -->
                    <div class="form-step active">
                        <div class="form-group">
                            <label>Current Illness History</label>
                            <textarea class="form-control" name="consultationsillnesshistory" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Recent Surgery</label>
                            <textarea class="form-control" name="consultationsrecentsurgery" required></textarea>
                        </div>
                        <button type="button" class="btn btn-primary next-step">Next</button>
                    </div>

                    <!-- Step 2 -->
                    <div class="form-step">
                        <div class="form-group">
                            <label>Diabetes</label><br>
                            <label><input type="radio" name="consultationsdiabetes" value="Diabetics" required> Diabetics</label>
                            <label><input type="radio" name="consultationsdiabetes" value="Non-Diabetics" required> Non-Diabetics</label>
                        </div>
                        <div class="form-group">
                            <label>Allergies</label>
                            <textarea class="form-control" name="consultationsallergies" required></textarea>
                        </div>
                        <div class="form-group">
                            <label>Others</label>
                            <textarea class="form-control" name="consultationsothers" required></textarea>
                        </div>
                        <button type="button" class="btn btn-secondary prev-step">Previous</button>
                        <button type="button" class="btn btn-primary next-step">Next</button>
                    </div>

                    <!-- Step 3 -->
                    <div class="form-step">
                        <div class="row payment-info" style="padding: 20px; border-radius: 5px;">
                            <div class="col-md-6 text-center" style="border-right: 1px solid #ddd;">
                                <h5><strong>Scan and Pay using UPI App</strong></h5>
                                <div class="barcode">
                                    <img src="img/barcode.png" alt="Barcode" style="max-width: 100%; height: auto; margin-bottom: 15px;">
                                </div>
                                <p>OR</p>
                                <p class="upi-id" style="font-weight: bold;">UPI ID: example@upi</p>
                            </div>
                            <div class="col-md-6 text-center">
                                <p><strong>Pay Using Any App</strong></p>
                                <p style="font-size: 1.5rem; font-weight: bold; color: #333;">&#8377; 600</p>
                                <p>(After Payment)</p>
                                <div class="form-group">
                                    <label>Enter Transaction ID</label>
                                    <input type="text" class="form-control" name="consultationstransactionid" required>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <label>CONSENT FOR ONLINE CONSULTATION</label>
                            <textarea class="form-control" name="consultationconsent" rows="3" placeholder="Enter your consent here..." required></textarea>
                        </div>
                        <div class="form-check text-center">
                            <input class="form-check-input" type="checkbox" name="consent" value="1" required>
                            <label class="form-check-label">Yes, I accept.</label>
                        </div>
                        <button type="submit" class="btn btn-success" name="consultationsubmit">Submit Appointment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const steps = document.querySelectorAll('.form-step');
        let currentStep = 0;

        document.querySelectorAll('.next-step').forEach(button => {
            button.addEventListener('click', () => {
                steps[currentStep].classList.remove('active');
                currentStep++;
                steps[currentStep].classList.add('active');
            });
        });

        document.querySelectorAll('.prev-step').forEach(button => {
            button.addEventListener('click', () => {
                steps[currentStep].classList.remove('active');
                currentStep--;
                steps[currentStep].classList.add('active');
            });
        });

        // Generate QR Code
        const doctorId = "<?php echo $doctor_id; ?>";
        const patientId = "<?php echo $_GET['patient_id'] ?? ''; ?>";
        const qrData = `Doctor ID: ${doctorId}, Patient ID: ${patientId}`;
        QRCode.toCanvas(document.getElementById('qrcode'), qrData, function (error) {
            if (error) console.error(error);
        });
    </script>
</body>
</html>
