<?php
session_start();
include 'get_db_connection.php';

if (isset($_POST['doctorsignupsubmit'])) {
    $doctorsname       = htmlspecialchars(($_POST['doctorsname']));
    $doctorsspecialty  = htmlspecialchars(trim($_POST['doctorsspecialty']));
    $doctorsemail      = trim($_POST['doctorsemail']);
    $doctorsphone      = trim($_POST['doctorsphone']);
    $doctorsexperience = trim($_POST['doctorsexperience']);
    $doctorspassword   = trim($_POST['doctorspassword']);

    $createddate       = date('Y-m-d H:i:s');

    $doctorsprofilepicture  =trim($_FILES['doctorsprofilepicture']['name']);

    if($doctorsprofilepicture){
       $doctorsprofilepicture_extension = pathinfo($doctorsprofilepicture,PATHINFO_EXTENSION);//get extention
       $doctorsprofilepicture_rename    = $doctorsname."_doctorsprofilepicture";//new name
       $doctorsprofilepicture_newname   = $doctorsprofilepicture_rename.'.'.$doctorsprofilepicture_extension;//new name and extension
       $doctorsprofilepicture_tmp       = $_FILES['doctorsprofilepicture']['tmp_name'];
       $doctorsprofilepicture_path      = 'doctorsprofilepicture/'.$doctorsprofilepicture_newname;
 }
    
    $query_check = "SELECT * FROM doctorsmaster WHERE doctorsemail = '$doctorsemail' OR doctorsphone = '$doctorsphone'";
    $result_check = mysqli_query($conn, $query_check);
    
    if (mysqli_num_rows($result_check) > 0) {
        $_SESSION['status_failed'] = "Email or phone number already exists. Please choose another.";
        header('location: doctor_signup.php');
        exit;
    } else {

        // Insert new user into the database
        
        $query_insert = "INSERT INTO doctorsmaster (doctorsprofilepicture, doctorsname, doctorsspecialty, doctorsemail, doctorsphone, doctorsexperience, doctorspassword, createddate, createdby, updateddate, updatedby) 
                                             VALUES ('$doctorsprofilepicture_newname','$doctorsname','$doctorsspecialty','$doctorsemail','$doctorsphone','$doctorsexperience','$doctorspassword','$createddate', 'admin', '$createddate', 'admin')";

        if (mysqli_query($conn, $query_insert)) {

            move_uploaded_file($doctorsprofilepicture_tmp, $doctorsprofilepicture_path);
            
            $_SESSION['status_success'] = "Sign-up successful. Please login.";
            header('location: doctor_signin.php');
            exit;
        } else {
            $_SESSION['status_failed'] = "Sign-up failed. Please try again.";
            header('location: doctor_signup.php'); 
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Sign-Up</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h1 class="text-center">Doctor Sign-Up</h1>
                <?php
                if (isset($_SESSION['status_success'])) {
                    echo "<div class='alert alert-success'>".$_SESSION['status_success']."</div>";
                    unset($_SESSION['status_success']);
                }

                if (isset($_SESSION['status_failed'])) {
                    echo "<div class='alert alert-danger'>".$_SESSION['status_failed']."</div>";
                    unset($_SESSION['status_failed']);
                }
                ?>
                
                <form method="POST" action="" enctype='multipart/form-data'>
                    <div class="form-group">
                        <label  class="col-form-label">Profile Picture</label><br>
                        <input type="file" name="doctorsprofilepicture" id="doctorsprofilepicture" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorsnameid">Name</label>
                        <input type="text" class="form-control" id="doctorsnameid" name="doctorsname" placeholder="Enter your Name" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorsspecialtyid">Specialty</label>
                        <input type="text" class="form-control" id="doctorsspecialtyid" name="doctorsspecialty" placeholder="Enter your Specialty" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorsemailid">Email</label>
                        <input type="email" class="form-control" id="doctorsemailid" name="doctorsemail" placeholder="Enter your Email" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorsphoneid">Phone Number</label>
                        <input type="number" class="form-control" id="doctorsphoneid" name="doctorsphone" placeholder="Enter your Phone Number" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorsexperienceid">Experience</label>
                        <input type="number" step="0.1" class="form-control" id="doctorsexperienceid" name="doctorsexperience" placeholder="Enter your Experience" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorspasswordid">Password</label>
                        <input type="password" class="form-control" id="doctorspasswordid" name="doctorspassword" placeholder="Enter your Password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block" name="doctorsignupsubmit">Sign Up</button>
                
                </form>
            </div>
        </div>
    </div>
</body>
</html>
