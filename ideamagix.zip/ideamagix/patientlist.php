<?php
session_start();
include 'get_db_connection.php'; // Include database connection

$doctor_id = $_SESSION['doctor_id']; // Assuming the logged-in doctor's ID is stored in the session

$sql = "SELECT * FROM patientsmaster WHERE doctor_id = '$doctor_id'";
$result = mysqli_query($conn, $sql);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient List</title>
    <!-- Include Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card {
            border-radius: 10px;
            overflow: hidden;
        }
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .card-body {
            text-align: center;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Patient List</h1>
        <div class="row">
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($patient = mysqli_fetch_assoc($result)) {
                    // Build the image path
                    $imagePath = "patientsprofilepicture/" .$patient['patientsprofilepicture'];
                    ?>
                    <div class="col-md-4 mb-4">
                        <div class="card shadow-sm">
                            <img src="<?php echo $imagePath; ?>" class="card-img-top" alt="patient Picture">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($patient['patientsname']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($patient['patientssurgeryhistory']); ?></p>
                                <p class="card-text"><?php echo htmlspecialchars($patient['patientsillnesshistory']); ?></p>
                                <a href="prescription_page.php?patient_id=<?php echo $patient['id']; ?>" class="btn btn-primary">Consult</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "<p class='text-center'>No patients found!</p>";
            }
            ?>
        </div>
    </div>

    <!-- Include Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
