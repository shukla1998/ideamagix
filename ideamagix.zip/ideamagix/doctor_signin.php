<?php
session_start();
include 'get_db_connection.php'; 


if (isset($_POST['doctorsigninsubmit'])) {
    // Sanitize user input
    $doctorsemail = mysqli_real_escape_string($conn, $_POST['doctorsemail']);
    $doctorspassword = $_POST['doctorspassword']; // Do not hash the password here, compare it later.

    // Query to find the doctor by email
    $query = "SELECT * FROM doctorsmaster WHERE doctorsemail = '$doctorsemail'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Fetch the doctor's data
        $doctor = mysqli_fetch_assoc($result);
        $stored_password = $doctor['doctorspassword']; // Password stored in the database

        // Check password (handles both plain text and hashed passwords)
        if ($stored_password === $doctorspassword || password_verify($doctorspassword, $stored_password)) {
            // Successful login
            echo "Login Successful";
            
            // Set session variables
            $_SESSION['doctor_id'] = $doctor['id'];
            $_SESSION['doctor_name'] = $doctor['name'];

            // Redirect to dashboard
            header("Location: patientlist.php");
            exit;
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "Doctor not found!";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Sign-In</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3 class="text-center">Doctor Sign-In</h3>
                
                <form method="POST">
                    <div class="form-group">
                        <label for="doctorsemailid">Email</label>
                        <input type="email" class="form-control" id="doctorsemailid" name="doctorsemail" placeholder="Enter your Email" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorspasswordid">Password</label>
                        <input type="password" class="form-control" id="doctorspasswordid" name="doctorspassword" placeholder="Enter your Password" required>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block" name="doctorsigninsubmit">Sign IN</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>


